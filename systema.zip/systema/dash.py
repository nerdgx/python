import tkinter as tk
from tkinter import messagebox
import mysql.connector


def connect_to_db():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="gym_management"
        )
    except mysql.connector.Error:
        messagebox.showerror(message="Failed to connect to database")
        return None


def click_green(all_mem):
    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM member")
    total_m = cursor.fetchone()[0]
    conn.close()
    all_mem.config(text=total_m)


def click_orange(all_inc):
    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    cursor.execute("SELECT cost FROM member")
    rows = cursor.fetchall()
    conn.close()
    total_c = sum(row[0] for row in rows)
    all_inc.config(text=f"₱{total_c}")


def click_red(total_male):
    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    query = """
    SELECT
        SUM(CASE WHEN gender = 'Male' THEN 1 ELSE 0 END) AS total_males
    FROM member
    """
    cursor.execute(query)
    sum_males = cursor.fetchone()[0]
    conn.close()
    total_male.config(text=sum_males)


def click_yellow(total_fel):
    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    query = """
    SELECT
        SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) AS total_females
    FROM member
    """
    cursor.execute(query)
    sum_females = cursor.fetchone()[0]
    conn.close()
    total_fel.config(text=sum_females)


def click_blue(blu_plan):
    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    query = """
    SELECT
        SUM(CASE WHEN ship_plan = 'Monthly' THEN 1 ELSE 0 END) AS total_monthly_plans
    FROM member
    """
    cursor.execute(query)
    sum_monthly = cursor.fetchone()[0]
    conn.close()
    blu_plan.config(text=sum_monthly)


def click_gray(gra_plan):
    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    query = """
    SELECT
        SUM(CASE WHEN ship_plan = 'Weekly' THEN 1 ELSE 0 END) AS total_weekly_plans
    FROM member
    """
    cursor.execute(query)
    sum_weekly = cursor.fetchone()[0]
    conn.close()
    gra_plan.config(text=sum_weekly)


def click_maroon(ma_plan):
    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    query = """
    SELECT
        SUM(CASE WHEN ship_plan = 'Daily' THEN 1 ELSE 0 END) AS total_daily_plans
    FROM member
    """
    cursor.execute(query)
    sum_daily = cursor.fetchone()[0]
    conn.close()
    ma_plan.config(text=sum_daily)


def back(dash_root):
    from main_form import menu_form
    menu_form()
    dash_root.destroy()


def dash_board():
    dash_root = tk.Toplevel()
    dash_root.title("Dashboard")
    dash_root_width = 1024
    dash_root_height = 530
    screen_width = dash_root.winfo_screenwidth()
    screen_height = dash_root.winfo_screenheight()
    x_position = (screen_width - dash_root_width) // 2
    y_position = (screen_height - dash_root_height) // 2
    dash_root.geometry(f"{dash_root_width}x{dash_root_height}+{x_position}+{y_position}")

    header_frame = tk.Frame(dash_root, bd=3, bg="#0308A1", height=40)
    header_frame.pack_propagate(False)
    header_frame.pack(fill="x")

    footer_frame = tk.Frame(dash_root, bd=3, bg="#0308A1", height=70)
    footer_frame.pack_propagate(False)
    footer_frame.pack(side="bottom", fill="x")

    tk.Label(header_frame, text="INDOMITABLE ZENITH GYM FITNESS", font=("Canva Sans", 10, "bold"), bg="#0308A1", fg="white").place(x=43, y=7)
    menu_button = tk.Menubutton(header_frame, text="☰", fg="white", bg="#0308A1", activebackground="#0308A1", activeforeground="black", font=("", 15))
    menu_button.place(x=0, y=0)
    menu = tk.Menu(menu_button, tearoff=0)
    menu.add_command(label="⬅ Back", command=lambda: back(dash_root))
    menu_button.config(menu=menu)

    body_frame = tk.Frame(dash_root, bg="white")
    body_frame.pack(fill="both", expand=True)

    green_frame = tk.Frame(body_frame, bd=1, relief="raised", width=210, height=140, bg="green")
    green_frame.place(x=30, y=30)
    tk.Label(green_frame, text="Total Members", fg="white", bg="green", font=("Canva Sans", 13, "bold")).place(x=10, y=20)
    all_mem = tk.Label(green_frame, text="0", fg="white", bg="green", font=("Canva Sans", 19, "bold"))
    all_mem.place(x=20, y=75)
    click_green(all_mem)

    orange_frame = tk.Frame(body_frame, bd=1, relief="raised", width=210, height=140, bg="#F96E2A")
    orange_frame.place(x=280, y=30)
    tk.Label(orange_frame, text="Current Income", fg="white", bg="#F96E2A", font=("Canva Sans", 13, "bold")).place(x=10, y=20)
    all_inc = tk.Label(orange_frame, text="0", fg="white", bg="#F96E2A", font=("Canva Sans", 19, "bold"))
    all_inc.place(x=20, y=75)
    click_orange(all_inc)

    red_frame = tk.Frame(body_frame, bd=1, relief="raised", width=210, height=140, bg="#C62E2E")
    red_frame.place(x=530, y=30)
    tk.Label(red_frame, text="Male Members", fg="white", bg="#C62E2E", font=("Canva Sans", 13, "bold")).place(x=10, y=20)
    total_male = tk.Label(red_frame, text="0", fg="white", bg="#C62E2E", font=("Canva Sans", 19, "bold"))
    total_male.place(x=20, y=75)
    click_red(total_male)

    yellow_frame = tk.Frame(body_frame, bd=1, relief="raised", width=210, height=140, bg="#FCC737")
    yellow_frame.place(x=780, y=30)
    tk.Label(yellow_frame, text="Female Members", fg="white", bg="#FCC737", font=("Canva Sans", 13, "bold")).place(x=10, y=20)
    total_fel = tk.Label(yellow_frame, text="0", fg="white", bg="#FCC737", font=("Canva Sans", 19, "bold"))
    total_fel.place(x=20, y=75)
    click_yellow(total_fel)

    blue_frame = tk.Frame(body_frame, bd=1, relief="raised", width=210, height=140, bg="#006BFF")
    blue_frame.place(x=30, y=205)
    tk.Label(blue_frame, text="Monthly Plans", fg="white", bg="#006BFF", font=("Canva Sans", 13, "bold")).place(x=10, y=20)
    blu_plan = tk.Label(blue_frame, text="0", fg="white", bg="#006BFF", font=("Canva Sans", 19, "bold"))
    blu_plan.place(x=20, y=75)
    click_blue(blu_plan)

    gray_frame = tk.Frame(body_frame, bd=1, relief="raised", width=210, height=140, bg="#A6AEBF")
    gray_frame.place(x=280, y=205)
    tk.Label(gray_frame, text="Weekly Plans", fg="white", bg="#A6AEBF", font=("Canva Sans", 13, "bold")).place(x=10, y=20)
    gra_plan = tk.Label(gray_frame, text="0", fg="white", bg="#A6AEBF", font=("Canva Sans", 19, "bold"))
    gra_plan.place(x=20, y=75)
    click_gray(gra_plan)

    mar_frame = tk.Frame(body_frame, bd=1, relief="raised", width=210, height=140, bg="#740938")
    mar_frame.place(x=530, y=205)
    tk.Label(mar_frame, text="Daily Plans", fg="white", bg="#740938", font=("Canva Sans", 13, "bold")).place(x=10, y=20)
    ma_plan = tk.Label(mar_frame, text="0", fg="white", bg="#740938", font=("Canva Sans", 19, "bold"))
    ma_plan.place(x=20, y=75)
    click_maroon(ma_plan)

    tk.Label(footer_frame, text="DASHBOARD", bg="#0308A1", fg="white", font=("Canva Sans", 13, "bold")).place(x=20, y=24)
    return dash_root
