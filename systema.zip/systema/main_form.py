import tkinter as tk
from tkinter import ttk  
from tkinter import messagebox
from dash import dash_board
import mysql.connector


def connect_to_db():
    try:
        return mysql.connector.connect(
            host = "localhost",
            user = "root",
            password = "",
            database = "gym_management")
    except mysql.connector.Error:
        messagebox.showerror(message="Failed to connect to database")
        return None
    
def delete_member(prim_id, tree):
    if messagebox.askyesno(message=f"Are you sure you want to delete member no. {prim_id}?"):
        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM member WHERE prim_id = %s", (prim_id,))
            conn.commit()
            conn.close()

            messagebox.showinfo(message="Member successfully deleted")
            load_data_into_tree(tree)  
        except mysql.connector.Error as e:
            messagebox.showerror(message=f"Error: {e}")

    
def edit_member(prim_id, tree):
   
    member_data = get_member_data(prim_id)
    if member_data:
        open_edit_window(prim_id, member_data, tree)

        
def get_member_data(prim_id):
    conn = connect_to_db()
    if not conn:
        return None
    cursor = conn.cursor()
    cursor.execute("SELECT first_name, last_name, age, contact, gender FROM member WHERE prim_id = %s", (prim_id,))
    member_data = cursor.fetchone()
    conn.close()
    return member_data


def open_edit_window(prim_id, member_data, tree):
    edit_window = tk.Toplevel()
    edit_window.title("Edit member")
    edit_window_width = 400
    edit_window_height = 400
    screen_width = edit_window.winfo_screenwidth()
    screen_height = edit_window.winfo_screenheight()
    x_position = (screen_width - edit_window_width) // 2
    y_position = (screen_height - edit_window_height) // 2
    edit_window.geometry(f"{edit_window_width}x{edit_window_height}+{x_position}+{y_position}")
    
    header =tk.Label(edit_window, text="Edit data", font=("Canva Sans", 11, "bold"))
    header.pack(pady=23)
    
    
    tk.Label(edit_window, text="First Name:").place(x=20, y=100)
    fname_entry = tk.Entry(edit_window, width=25, font=("Canva Sans", 11))
    fname_entry.place(x=100, y=100)
    tk.Label(edit_window, text="Last Name:").place(x=20, y=130)
    lname_entry = tk.Entry(edit_window, width=25, font=("Canva Sans", 11))
    lname_entry.place(x=100, y=130)
    tk.Label(edit_window, text="Age:").place(x=20, y=160)
    age_entry = tk.Entry(edit_window, width=25, font=("Canva Sans", 11))
    age_entry.place(x=100, y=160)
    tk.Label(edit_window, text="Contact #:").place(x=20, y=190)
    contact_entry = tk.Entry(edit_window, width=25, font=("Canva Sans", 11))
    contact_entry.place(x=100, y=190)
    tk.Label(edit_window, text="Gender:").place(x=20, y=220)
    gender_entry = tk.Entry(edit_window, width=25, font=("Canva Sans", 11))
    gender_entry.place(x=100, y=220)
    
    tk.Label(edit_window, text="Plan:").place(x=20, y=250)
    plan = ["Monthly", "Weekly", "Daily"]
    type_plan = ttk.Combobox(edit_window, width=26, font=("Canva Sans", 10), values=plan, state="readonly")
    type_plan.place(x=100, y=250)
    
    
    button = tk.Button(edit_window, text="Save", font=("Canva Sans", 11), bg="#222831", activebackground="gray",  fg="white", activeforeground="white",  width=25, command=lambda: save_edit(prim_id, fname_entry, lname_entry, age_entry, contact_entry, gender_entry, type_plan, tree, edit_window))
    button.place(x=90, y=310)
    
def save_edit(prim_id, fname_entry, lname_entry, age_entry, contact_entry, gender_entry, type_plan, tree, edit_window):
    def calculate_cost(plan):
        if plan == "Monthly":
            return 1800.00
        elif plan == "Weekly":
            return 420.00
        elif plan == "Daily":
            return 60.00
        
    first_name = fname_entry.get()
    last_name = lname_entry.get()
    age = age_entry.get()
    contact = contact_entry.get()
    gender = gender_entry.get()
    ship_plan = type_plan.get()


    if not first_name or not last_name or not age or not contact or not gender or not ship_plan:
        messagebox.showerror(message="All fields are required")
        return None
    
    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        cost = calculate_cost(ship_plan)

        query = """
        UPDATE member 
        SET first_name=%s, last_name=%s, age=%s, contact=%s, 
            gender=%s, ship_plan=%s, cost=%s 
        WHERE prim_id=%s
        """
        cursor.execute(query, (first_name, last_name, age, contact, gender, ship_plan, cost, prim_id))
        conn.commit()
        conn.close()

        messagebox.showinfo(message="Member successfully updated")
        load_data_into_tree(tree)
        edit_window.destroy()
    except mysql.connector.Error as e:
        messagebox.showerror(message=f"Error: {e}")


def load_data_into_tree(tree):
    for item in tree.get_children():
        tree.delete(item)  

    conn = connect_to_db()
    if not conn:
        return
    cursor = conn.cursor()
    query = "SELECT prim_id, first_name, last_name, age, contact, gender, ship_plan, cost FROM member"
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    
    for index, row in enumerate(rows):
        prim_id = row[0]
        custom_text_9 = "📝"
        custom_text_10 = "     🗑️"
        tag_name = "even" if index % 2 == 0 else "odd"
        tree.insert("", "end", values=row + (custom_text_9, custom_text_10), tags=(f"row_{prim_id}", tag_name,))
    
    tree.tag_configure("even")
    tree.tag_configure("odd", background="black", foreground="white") 

   

def search_results(result, root):
    if not result:
        messagebox.showwarning(message="No results found")
        return
        
    result_window = tk.Toplevel(root)
    result_window.title("Searching......")
    result_window.config(bg="#F0F0F0")
    result_window_width = 900
    result_window_height = 200
    screen_width = result_window.winfo_screenwidth()
    screen_height = result_window.winfo_screenheight()
    x_position = (screen_width - result_window_width) // 2
    y_position = (screen_height - result_window_height) // 2
    result_window.geometry(f"{result_window_width}x{result_window_height}+{x_position}+{y_position}")
    
    style = ttk.Style()
    style.configure("Custom.Treeview.Heading", background="grey", font=("Canva Sans", 10, "bold"))
    style.map("Custom.Treeview.Heading", background=[("active", "grey")])
    style.theme_use("default") 
    tree = ttk.Treeview(result_window, columns=("ID", "First_name", "Last_name", "Age", "Contact", "Gender", "Memship_Plan", "Cost"), show="headings")
    tree.heading("ID", text="No.")
    tree.heading("First_name", text="First_Name")
    tree.heading("Last_name", text="Last_Name")
    tree.heading("Age", text="Age")
    tree.heading("Contact", text="Contact")
    tree.heading("Gender", text="Gender")
    tree.heading("Memship_Plan", text="Membership_Plan")
    tree.heading("Cost", text="Cost")
    
    tree.column("ID", width=50, anchor="center")
    tree.column("First_name", width=150, anchor="center")
    tree.column("Last_name", width=150, anchor="center")
    tree.column("Age", width=60, anchor="center")
    tree.column("Contact", width=110, anchor="center")
    tree.column("Gender", width=100, anchor="center")
    tree.column("Memship_Plan", width=150, anchor="center")
    tree.column("Cost", width=60, anchor="center")
    tree.pack(pady=10, padx=10,fill=tk.BOTH, expand=True)
    
    for row in result:
        prim_id = row[0]
        tree.insert("", "end", values=row, tags=(f"row_{prim_id}",))
        
    def on_close():
        result_window.destroy()
    
    result_window.protocol("WM_DELETE_WINDOW", on_close)


def search(search_entry):
    query = search_entry.get()        
    if not query:
        messagebox.showerror(message="Please enter a name or ID")
        return
    conn = connect_to_db()
    if not conn:
        return
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT prim_id, first_name, last_name, age, contact, gender, ship_plan, cost FROM member WHERE first_name LIKE %s OR prim_id=%s", (f"{query}%", query))
        result = cursor.fetchall()
        search_results(result, root)
    except mysql.connector.Error as err:
        messagebox.showerror(message=f"Error: {err}")
    finally:
        conn.close
        
def out(root):
    response = messagebox.askyesno(message="Are you sure you want to log out?")
    if response:
        root.destroy()
        from login import login
        login()
        
    else:
        pass


def show(tree):
    load_data_into_tree(tree)
 


def add(new_root, tree, fname_entry, lname_entry, age_entry, contact_entry, gender_entry, type_plan):
    def calculate_cost(plan):
        if plan == "Monthly":
            return 1800.00
        elif plan == "Weekly":
            return 420.00
        elif plan == "Daily":
            return 60.00
        
    first_name = fname_entry.get()
    last_name = lname_entry.get()
    age = age_entry.get()
    contact = contact_entry.get()
    gender = gender_entry.get()
    ship_plan = type_plan.get()
    
    
    if not first_name or not last_name or not age or not contact or not gender or not ship_plan:
        messagebox.showerror(message="All fields are required")
        return None
    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        cost = calculate_cost(ship_plan)
        cursor.execute(
            "INSERT INTO member (first_name, last_name, age, contact, gender, ship_plan, cost) VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (first_name, last_name, age, contact, gender, ship_plan, cost),
        )
        conn.commit()
        conn.close()
        
        messagebox.showinfo(message="Member successfully added")
        
        fname_entry.delete(0, tk.END)
        lname_entry.delete(0, tk.END)
        age_entry.delete(0, tk.END)
        contact_entry.delete(0, tk.END)
        gender_entry.delete(0, tk.END)
        type_plan.delete(0, tk.END)
        
        
        load_data_into_tree(tree)
        new_root.destroy()
    except mysql.connector.Error as e:
        messagebox.showerror(message=f"Error: {e}")

def set_placeholder(entry, placeholder_text, is_password=False):
    entry.insert(0, placeholder_text)
    entry.config(fg="grey")
    entry.bind("<FocusIn>", lambda e: clear_placeholder(entry, placeholder_text, is_password))
    entry.bind("<FocusOut>", lambda e: restore_placeholder(entry, placeholder_text, is_password))

def clear_placeholder(entry, placeholder_text, is_password):
    if entry.get() == placeholder_text:
        entry.delete(0, tk.END)
        entry.config(fg="black")
        if is_password:
            entry.config(show="*")

def restore_placeholder(entry, placeholder_text, is_password):
    if not entry.get():
        entry.insert(0, placeholder_text)
        entry.config(fg="grey")
        if is_password:
            entry.config(show="")
            
def open_add(root, tree):
    new_root = tk.Toplevel(root)
    new_root.title("Add member")
    new_root_width = 400
    new_root_height = 400
    screen_width = new_root.winfo_screenwidth()
    screen_height = new_root.winfo_screenheight()
    x_position = (screen_width - new_root_width) // 2
    y_position = (screen_height - new_root_height) // 2
    new_root.geometry(f"{new_root_width}x{new_root_height}+{x_position}+{y_position}")
    
    header =tk.Label(new_root, text="Fill in", font=("Canva Sans", 11, "bold"))
    header.pack(pady=23)
    
    

    tk.Label(new_root, text="First Name:").place(x=20, y=100)
    fname_entry = tk.Entry(new_root, width=25, font=("Canva Sans", 11))
    fname_entry.place(x=100, y=100)
    tk.Label(new_root, text="Last Name:").place(x=20, y=130)
    lname_entry = tk.Entry(new_root, width=25, font=("Canva Sans", 11))
    lname_entry.place(x=100, y=130)
    tk.Label(new_root, text="Age:").place(x=20, y=160)
    age_entry = tk.Entry(new_root, width=25, font=("Canva Sans", 11))
    age_entry.place(x=100, y=160)
    tk.Label(new_root, text="Contact #:").place(x=20, y=190)
    contact_entry = tk.Entry(new_root, width=25, font=("Canva Sans", 11))
    contact_entry.place(x=100, y=190)
    tk.Label(new_root, text="Gender:").place(x=20, y=220)
    gender_entry = tk.Entry(new_root, width=25, font=("Canva Sans", 11))
    gender_entry.place(x=100, y=220)
    
    tk.Label(new_root, text="Plan:").place(x=20, y=250)
    plan = ["Monthly", "Weekly", "Daily"]
    type_plan = ttk.Combobox(new_root, width=26, font=("Canva Sans", 10), values=plan, state="readonly")
    type_plan.place(x=100, y=250)

    
    
    button = tk.Button(new_root, text="Submit", font=("Canva Sans", 11), bg="#222831", activebackground="gray",  fg="white", activeforeground="white",  width=25, command=lambda: add(new_root, tree, fname_entry, lname_entry, age_entry, contact_entry, gender_entry, type_plan))
    button.place(x=85, y=310)
    
    return new_root
    

def menu_form():
    global root
    root = tk.Tk()
    root.title("Indomitable Zenith Gym Management System")
    root_width = 1024
    root_height = 530
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x_position = (screen_width - root_width) // 2
    y_position = (screen_height - root_height) // 2
    root.geometry(f"{root_width}x{root_height}+{x_position}+{y_position}")
    
    
    header_frame = tk.Frame(root, bd=3, bg="#0308A1", height=40)
    header_frame.pack_propagate(False)
    header_frame.pack(fill="x")
    header = tk.Label(header_frame, text="INDOMITABLE ZENITH GYM FITNESS", bg="#0308A1", fg="white", font=("Aeonik Typface", 10, "bold"))
    header.place(x=43, y=7)
    
    
    member_window = tk.Frame(root)
    member_window.pack(fill="both", expand=True)
    
    footer_frame = tk.Frame(root, bd=3, bg="#0308A1", height=70)
    footer_frame.pack_propagate(False)
    footer_frame.pack(side="bottom", fill="x")
    
                  
    search_entry = tk.Entry(member_window)
    set_placeholder(search_entry, "Search...")
    search_entry.place(x=835, y=10, height=27)
    search_button = tk.Button(member_window, width=2, text="➤ ", font=("", 8), fg="white", bg="black", command=lambda: search(search_entry))   
    search_button.place(x=963, y=11) 
    
    menu_button = tk.Menubutton(header_frame, text="☰", fg="white", bg="#0308A1", activebackground="#0308A1", activeforeground="black", font=("", 15))
    menu_button.place(x=0, y=0)
    menu = tk.Menu(menu_button, tearoff=0)
    menu.add_command(label="👁 View list", command=lambda:show(tree))
    menu.add_command(label="📊 Dashboard", command=lambda: (root.withdraw(), dash_board()))
    menu.add_command(label="⬅️ Log out", command=lambda:out(root))
    menu_button.config(menu=menu)
    
    tree_frame = tk.Frame(member_window)
    tree_frame.pack_propagate(True)
    tree_frame.place(x=36, y=60)

    style = ttk.Style()
    style.configure("Custom.Treeview.Heading", relief="sunken", bd=3, background="grey", font=("Canva Sans", 10, "bold"))
    style.map("Custom.Treeview.Heading", background=[("active", "grey")])
    style.theme_use("default")  
    
    tree = ttk.Treeview(tree_frame, height=13, columns=("ID", "First_name", "Last_name", "Age", "Contact", "Gender", "Memship_Plan", "Cost", "Edit", "Delete"), show="headings")
    tree.heading("ID", text="No.")
    tree.heading("First_name", text="First_Name")
    tree.heading("Last_name", text="Last_Name")
    tree.heading("Age", text="Age")
    tree.heading("Contact", text="Contact #")
    tree.heading("Gender", text="Gender")
    tree.heading("Memship_Plan", text="Membership_Plan")
    tree.heading("Cost", text="Cost")
    tree.heading("Edit", text="Edit")
    tree.heading("Delete", text="Delete")
    
    tree.column("ID", width=50, anchor="center")
    tree.column("First_name", width=150, anchor="center")
    tree.column("Last_name", width=150, anchor="center")
    tree.column("Age", width=60, anchor="center")
    tree.column("Contact", width=130, anchor="center")
    tree.column("Gender", width=100, anchor="center")
    tree.column("Memship_Plan", width=150, anchor="center")
    tree.column("Cost", width=60, anchor="center")
    tree.column("Edit", width=50, anchor="center")
    tree.column("Delete", width=50, anchor="center")

    tree.pack(fill="both", expand=True)
    
  
    def on_tree_click(event):
     
        item = tree.identify_row(event.y)
        column = tree.identify_column(event.x)
    
        if not item:
            return
    
        prim_id = tree.item(item, "values")[0]  
    
        if column == "#10":  
            delete_member(prim_id, tree)
    
        elif column == "#9": 
            edit_member(prim_id, tree)
            
    tree.bind("<Button-1>", on_tree_click)

        
    #global value_label
    
    tk.Label(footer_frame, text="MEMBERS", bg="#0308A1", fg="white", font=("Aeonik Typface", 13, "bold")).place(x=20, y=24)
    add_button = tk.Button(footer_frame, fg="black", bg="white", activebackground="white", text="➕ ", command=lambda:open_add(root, tree))
    add_button.place(x=870, y=23)
    tk.Label(footer_frame, text="Add Member", font=("Aeonik Typface", 11, "bold"), fg="white", bg="#0308A1").place(x=905, y=24)
    show(tree)
    
    return root

if __name__ == "__main__":
    menu_form().mainloop()

