import tkinter as tk 
import mysql.connector
from tkinter import messagebox
from main_form import menu_form

def connect_to_db():
    try:
        return mysql.connector.connect(
            host = "localhost",
            user = "root",
            password = "",
            database = "gym_management")
    except mysql.connector.Error:
        messagebox.showerror(message="Failed to connect to database")
        return None

def on_close():
    window.destroy()
        
def login():
    user = entry_user.get()
    pas = entry_pass.get()
    
    conn = connect_to_db()
    if not conn:
        return None
    cursor = conn.cursor()
    query = "SELECT * FROM login WHERE user = %s AND pas = %s"
    cursor.execute(query, (user, pas))
    result = cursor.fetchone()
    conn.close()
    
    if result:
        messagebox.showinfo(message="Welcome to fithive gym management") 
        window.destroy()
        menu_form()
    else:
        messagebox.showerror(message="Invalid username and password")


def set_placeholder(entry, placeholder_text, is_password=False):
    entry.insert(0, placeholder_text)
    entry.config(fg="grey")
    entry.bind("<FocusIn>", lambda e: clear_placeholder(entry, placeholder_text, is_password))
    entry.bind("<FocusOut>", lambda e: restore_placeholder(entry, placeholder_text, is_password))

def clear_placeholder(entry, placeholder_text, is_password):
    if entry.get() == placeholder_text:
        entry.delete(0, tk.END)
        entry.config(fg="black")
        if is_password:
            entry.config(show="*")

def restore_placeholder(entry, placeholder_text, is_password):
    if not entry.get():
        entry.insert(0, placeholder_text)
        entry.config(fg="grey")
       
        if is_password:
            entry.config(show="")

window = tk.Tk()
window.config(bg="#EEEEEE")
window_width = 400
window_height = 400
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
x_position = (screen_width - window_width) // 2
y_position = (screen_height - window_height) // 2
window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

header = tk.Label(window, bg="#F0F0F0",text="Login", font=("Aeonik Typface", 20, "bold"))
header.place(x=162, y=68)

global entry_user,entry_pass
entry_user = tk.Entry(window, width=25, font=("Aeonik Typface", 10))
set_placeholder(entry_user, "Username")
entry_user.place(x=110, y=148, height=35)
entry_pass = tk.Entry(window, width=25, font=("Aeonik Typface", 10))
set_placeholder(entry_pass, "Password", is_password=True)
entry_pass.place(x=110, y=195, height=35)

login_quote = tk.Label(window, bg="#F0F0F0",text="Exercise? I thought you say unli-rice", font=("Aeonik Typface", 7, "italic"))
login_quote.place(x=120, y=284)
login_button = tk.Button(window, text="Login", relief="raised", bd=2, font=("Aeonik Typface", 11), bg="black", fg="white", activebackground="grey", activeforeground="black", width=19, command=login)
login_button.place(x=108, y=315)

window.protocol("WM_DELETE_WINDOW", on_close)

window.mainloop()

